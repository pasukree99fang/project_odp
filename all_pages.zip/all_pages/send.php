
<form action="save.php" method="post">
    <input type="text" placeholder="User ID " name="user_id" id="msg_text"/>
    <input type="text" placeholder="ข้อความ" name="msg_text" id="msg_text"/>
  <button type="submit">SEND</button>
</form>