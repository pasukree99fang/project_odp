<form action="save.php" method="post">
  <input type="text" name="msg_text"/>
  <button type="submit">SEND</button>
</form> 