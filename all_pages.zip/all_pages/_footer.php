<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version Final</b> 
    </div>
    <strong>ODP : Online Document Process for organization.</strong>
  </footer> 